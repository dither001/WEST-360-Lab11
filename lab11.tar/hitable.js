
class hit_record {
    get t() { return this.t_val; };
    set t(val){ this.t_val = val; };

    // add your code here:
}




