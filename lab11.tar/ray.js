
class ray{
    // add your code here:

}