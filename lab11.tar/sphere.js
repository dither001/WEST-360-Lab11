
class sphere{
    // add your code here:

}